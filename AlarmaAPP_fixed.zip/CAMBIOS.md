# AlarmaAPP — bugs arreglados

Resumen de los 10 fixes aplicados sobre el proyecto original.

## 1. NuevaAlarmaActivity ya registra el geofence al crear
`AlarmaViewModel.insertar(alarma, callback)` ahora **siempre** registra el geofence
si la alarma esta activa, antes de devolver el id al callback. Antes, las alarmas
creadas desde NuevaAlarmaActivity nunca se monitorizaban hasta que las apagabas
y volvias a encender.

## 2. La API key de Google Maps ya no esta en el manifest
- En `AndroidManifest.xml` la `<meta-data>` usa el placeholder `${MAPS_API_KEY}`.
- En `app/build.gradle.kts` se lee de `local.properties` (que esta en `.gitignore`).
- La key actual ya esta puesta en `local.properties` para que la app compile
  sin tocar nada. Si subes el proyecto a Git, la key NO se sube.
- Tienes `local.properties.example` como referencia para anadir tu propia key.

## 3. Las alarmas siguen funcionando despues de reiniciar el movil
Nuevo `BootReceiver` (en `view/BootReceiver.java`) que escucha
`BOOT_COMPLETED` y vuelve a registrar todas las alarmas activas en el
GeofencingClient. Registrado en el manifest. Usa `goAsync()` para no bloquear
el hilo principal.

Para que esto funcione, anadi al `AlarmaDao` una query directa nueva:
`getAlarmasActivasDirecto()` (sin LiveData, para usar en hilo de fondo).

## 4. Editar una alarma ya no la reactiva sola
`EditarAlarmaActivity` ahora recibe `activa` por intent y lo conserva al
guardar. `ListaAlarmasActivity` lo pasa con `intent.putExtra("activa", ...)`.

## 5. Color cian de las categorias ya funciona
Anadido `<RadioButton id="rbCian">` en `dialog_categoria.xml` y manejado en los
dos listeners de `CategoriasActivity` (crear y editar).

## 6. Codigo muerto eliminado
Borrados `view/MapaFragment.java` y `layout/fragment_mapa.xml`. No los usaba nadie.

## 7. fallbackToDestructiveMigration cambiado
`AppDatabase` ahora usa `fallbackToDestructiveMigrationOnDowngrade()`. Asi:
- Bajar version (raro, solo en desarrollo) borra la BD y empieza limpio.
- Subir version sin escribir una `Migration` hace que la app crashee
  intencionadamente, para obligar a escribir migraciones y NO perder datos
  del usuario en produccion.

## 8. NPE protegido en GeofenceBroadcastReceiver
Comprobamos que `getTriggeringGeofences()` no sea null ni vacia antes de
acceder al primer elemento.

## 9. Import duplicado eliminado
En `AlarmaAdapter.java` habia dos `import com.example.alarmaapp.model.Categoria`.
Dejamos solo uno.

## 10. Tema oscuro coherente
`values-night/themes.xml` ahora define `Theme.AlarmaApp` con los mismos colores
claros del tema principal, en lugar del residuo `Base.Theme.AlarmaAPP` que no
se usaba. Asi en modo oscuro del sistema la app se ve igual de bien y no se
mezclan estilos.

---

## Archivos nuevos
- `app/src/main/java/com/example/alarmaapp/view/BootReceiver.java`
- `local.properties` (con la API key, no se sube a Git)
- `local.properties.example`
- este README

## Archivos eliminados
- `app/src/main/java/com/example/alarmaapp/view/MapaFragment.java`
- `app/src/main/res/layout/fragment_mapa.xml`

## Archivos modificados
- `AndroidManifest.xml`
- `app/build.gradle.kts`
- `app/src/main/java/com/example/alarmaapp/crud/EditarAlarmaActivity.java`
- `app/src/main/java/com/example/alarmaapp/database/AlarmaDao.java`
- `app/src/main/java/com/example/alarmaapp/database/AppDatabase.java`
- `app/src/main/java/com/example/alarmaapp/navegacion/CategoriasActivity.java`
- `app/src/main/java/com/example/alarmaapp/navegacion/ListaAlarmasActivity.java`
- `app/src/main/java/com/example/alarmaapp/view/AlarmaAdapter.java`
- `app/src/main/java/com/example/alarmaapp/view/GeofenceBroadcastReceiver.java`
- `app/src/main/java/com/example/alarmaapp/viewmodel/AlarmaViewModel.java`
- `app/src/main/res/layout/dialog_categoria.xml`
- `app/src/main/res/values-night/themes.xml`
