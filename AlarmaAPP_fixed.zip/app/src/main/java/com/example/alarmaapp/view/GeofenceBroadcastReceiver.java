package com.example.alarmaapp.view;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.alarmaapp.AlarmaActivaActivity;
import com.example.alarmaapp.database.AppDatabase;
import com.example.alarmaapp.model.Alarma;
import com.example.alarmaapp.model.HistorialActivacion;
import com.example.alarmaapp.model.Repeticion;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);

        if (geofencingEvent == null || geofencingEvent.hasError()) {
            return;
        }

        int transicion = geofencingEvent.getGeofenceTransition();

        if (transicion == Geofence.GEOFENCE_TRANSITION_ENTER) {

            // La lista de geocercas que dispararon el evento puede venir null o vacia
            // (en la practica casi nunca pasa, pero conviene blindarse para no crashear).
            java.util.List<com.google.android.gms.location.Geofence> disparadas =
                    geofencingEvent.getTriggeringGeofences();
            if (disparadas == null || disparadas.isEmpty()) return;

            String idGeofence = disparadas.get(0).getRequestId();

            new Thread(() -> {
                AppDatabase db = AppDatabase.getInstance(context);
                Alarma alarma = db.alarmaDao().getAlarmaPorIdDirecto(Long.parseLong(idGeofence));

                if (alarma == null) return;

                // ── Comprobar repetición ──────────────────────────────────────
                Repeticion rep = db.repeticionDao().getRepeticionPorAlarmaDirecto(alarma.getId());
                if (rep != null) {
                    int diaSemana = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
                    boolean hoyActivo = false;

                    switch (diaSemana) {
                        case Calendar.MONDAY:    hoyActivo = rep.isLunes(); break;
                        case Calendar.TUESDAY:   hoyActivo = rep.isMartes(); break;
                        case Calendar.WEDNESDAY: hoyActivo = rep.isMiercoles(); break;
                        case Calendar.THURSDAY:  hoyActivo = rep.isJueves(); break;
                        case Calendar.FRIDAY:    hoyActivo = rep.isViernes(); break;
                        case Calendar.SATURDAY:  hoyActivo = rep.isSabado(); break;
                        case Calendar.SUNDAY:    hoyActivo = rep.isDomingo(); break;
                    }

                    boolean algunDiaSeleccionado = rep.isLunes() || rep.isMartes()
                            || rep.isMiercoles() || rep.isJueves() || rep.isViernes()
                            || rep.isSabado() || rep.isDomingo();

                    // Si hay días configurados y hoy no es uno de ellos, no activar
                    if (algunDiaSeleccionado && !hoyActivo) return;
                }

                // ── Guardar en historial ──────────────────────────────────────
                String fecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        .format(new Date());
                String hora  = new SimpleDateFormat("HH:mm", Locale.getDefault())
                        .format(new Date());

                db.historialDao().insertar(new HistorialActivacion(
                        alarma.getId(), alarma.getNombre(), fecha, hora));

                // ── Lanzar pantalla de alarma ─────────────────────────────────
                Intent alarmaIntent = new Intent(context, AlarmaActivaActivity.class);
                alarmaIntent.putExtra("nombre", alarma.getNombre());
                alarmaIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(alarmaIntent);
            }).start();
        }
    }
}