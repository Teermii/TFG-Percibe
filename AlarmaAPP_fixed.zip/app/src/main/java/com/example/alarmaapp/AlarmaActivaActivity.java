package com.example.alarmaapp;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.TextView;

import android.app.KeyguardManager;
import android.os.Build;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

public class AlarmaActivaActivity extends AppCompatActivity {

    // El objeto que reproduce el sonido de alarma
    private Ringtone ringtone;

    // El objeto que controla la vibración
    private Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Forzar que se muestre sobre la pantalla de bloqueo
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (keyguardManager != null) {
                keyguardManager.requestDismissKeyguard(this, null);
            }
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            );
        }

        setContentView(R.layout.activity_alarma_activa);

        // Recogemos el nombre de la alarma que nos manda el BroadcastReceiver
        String nombreAlarma = getIntent().getStringExtra("nombre");

        TextView tvNombre = findViewById(R.id.tvNombre);
        Button btnParar = findViewById(R.id.btnParar);

        tvNombre.setText(nombreAlarma != null ? nombreAlarma : "Alarma");

        // ── Sonido ────────────────────────────────────────────────────────────
        // RingtoneManager.TYPE_ALARM obtiene el tono de alarma que el usuario
        // tiene configurado en su móvil — no necesitamos ningún archivo de audio
        Uri sonidoAlarma = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        ringtone = RingtoneManager.getRingtone(this, sonidoAlarma);
        ringtone.play();

        // ── Vibración ─────────────────────────────────────────────────────────
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        // Patrón: espera 0ms, vibra 1000ms, pausa 500ms, repite desde índice 0
        long[] patron = {0, 1000, 500};
        vibrator.vibrate(VibrationEffect.createWaveform(patron, 0));

        // ── Botón parar ───────────────────────────────────────────────────────
        btnParar.setOnClickListener(v -> pararAlarma());
    }

    private void pararAlarma() {
        // Parar el sonido
        if (ringtone != null && ringtone.isPlaying()) {
            ringtone.stop();
        }
        // Parar la vibración
        if (vibrator != null) {
            vibrator.cancel();
        }
        // Cerrar la pantalla
        finish();
    }

    // Si el usuario pulsa atrás también paramos todo
    @Override
    public void onBackPressed() {
        pararAlarma();
    }

    // Si la Activity se destruye por cualquier motivo, aseguramos que para todo
    @Override
    protected void onDestroy() {
        super.onDestroy();
        pararAlarma();
    }
}