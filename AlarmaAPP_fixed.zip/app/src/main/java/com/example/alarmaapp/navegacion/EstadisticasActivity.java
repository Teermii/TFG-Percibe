package com.example.alarmaapp.navegacion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmaapp.R;
import com.example.alarmaapp.navegacion.DetalleEstadisticasActivity;
import com.example.alarmaapp.view.AlarmaAdapter;
import com.example.alarmaapp.viewmodel.AlarmaViewModel;

public class EstadisticasActivity extends AppCompatActivity {

    private AlarmaViewModel viewModel;
    private AlarmaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        TextView tvVacia = findViewById(R.id.tvVacia);

        viewModel = new ViewModelProvider(this).get(AlarmaViewModel.class);

        // Reutilizamos AlarmaAdapter pero el click abre DetalleEstadisticasActivity
        adapter = new AlarmaAdapter(viewModel, alarma -> {
            Intent intent = new Intent(this, DetalleEstadisticasActivity.class);
            intent.putExtra("alarmaId", alarma.getId());
            intent.putExtra("nombre", alarma.getNombre());
            startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        viewModel.getTodasLasAlarmas().observe(this, alarmas -> {
            adapter.setAlarmas(alarmas);
            tvVacia.setVisibility(alarmas.isEmpty() ? View.VISIBLE : View.GONE);
            recyclerView.setVisibility(alarmas.isEmpty() ? View.GONE : View.VISIBLE);
        });
    }
}