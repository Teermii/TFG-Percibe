package com.example.alarmaapp.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.alarmaapp.model.Alarma;
import com.example.alarmaapp.model.Categoria;
import com.example.alarmaapp.model.HistorialActivacion;
import com.example.alarmaapp.model.Repeticion;

@Database(
    entities = {Alarma.class, HistorialActivacion.class, Categoria.class, Repeticion.class},
    version = 4,
    exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instancia;

    public abstract AlarmaDao alarmaDao();
    public abstract HistorialDao historialDao();
    public abstract CategoriaDao categoriaDao();
    public abstract RepeticionDao repeticionDao(); // Nuevo DAO

    public static synchronized AppDatabase getInstance(Context context) {
        if (instancia == null) {
            instancia = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "alarma_database"
            )
            /* fallbackToDestructiveMigrationOnDowngrade:
             *   - Si bajamos de version (raro, solo en desarrollo), borra la bd y empieza limpio.
             *   - Si SUBIMOS de version sin definir una Migration, la app crasheara
             *     a proposito para obligar al desarrollador a escribir la migracion
             *     y NO perder los datos del usuario en produccion.
             *
             * Para anadir una migracion futura (por ejemplo de la v4 a la v5):
             *   .addMigrations(new Migration(4, 5) { ... })
             */
            .fallbackToDestructiveMigrationOnDowngrade()
            .build();
        }
        return instancia;
    }
}
